# Un premier programme Python

1. Créez un fichier `hello.py` et ouvrez-le.
1. Saisissez les lignes suivantes dans le fichier
    ```python
    msg = "hello world"
    print(msg.capitalize())
    ```
1. Exécutez le programme
    1. dans l'IDE
    1. dans le terminal
